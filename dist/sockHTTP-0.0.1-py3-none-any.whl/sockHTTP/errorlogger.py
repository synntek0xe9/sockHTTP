


class Errorlogger():

    def saveError(self, msg):
        None

main = Errorlogger()