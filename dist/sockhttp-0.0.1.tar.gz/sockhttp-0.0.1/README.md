# sockHTTP python lib & examples on HTTP using sockets 

This project uses standars socket library.
Main reason by which project was created is bit more of speed (like 8x more comparing to requests library).
It should be great choice to use it or at least inspire of code when building python fuzzer or crawler basing on sockets.
It's a bit slower than ffuf (like 20% on same amount of threads), but it's scriptable so schould be of use.

# Instalation
Download recent package using releases button (sorry not added to pip packages yet)

then install with pip

windows
```powershell pip install sockHTTP C:\path\to\folder\in\which\file\is```
linux
```bash pip install sockHTTP /path/to/folder/where/file/is```