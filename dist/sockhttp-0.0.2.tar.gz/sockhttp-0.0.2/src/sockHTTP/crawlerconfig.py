



OPTION_WORDLIST_BIG = "./wordlists/dirb/wordlists/big.txt"
OPTION_WORDLIST_MEDIUM = "./wordlists/dirb/wordlists/common.txt"
OPTION_WORDLIST_SMALL = "./wordlists/dirb/wordlists/small.txt"



