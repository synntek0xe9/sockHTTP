


class ErrorLogger():

    def saveError(self, msg):
        None

main = ErrorLogger()